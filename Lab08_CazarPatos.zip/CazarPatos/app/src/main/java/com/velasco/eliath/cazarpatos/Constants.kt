package com.velasco.eliath.cazarpatos


const val EXTRA_LOGIN = "EXTRA_LOGIN"
const val MIN_PASSWORD_LENGTH = 8
const val LOGIN_KEY = "LOGIN_KEY"
const val PASSWORD_KEY = "PASSWORD_KEY"
const val SHAREDINFO_FILENAME = "mySharedInformation.dat"